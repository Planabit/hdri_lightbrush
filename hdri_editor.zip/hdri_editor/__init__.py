bl_info = {"name": "HDRI Editor", "version": (1, 0, 0), "blender": (4, 0, 0), "category": "3D View"}

import bpy
import os
from bpy.types import Panel, Operator, PropertyGroup, AddonPreferences
from bpy.props import StringProperty, FloatProperty, EnumProperty, BoolProperty
from bpy_extras.io_utils import ImportHelper

# Note: bpy.utils.previews is deprecated in Blender 4.2+
# We use direct image preview approach instead

class HDRI_EditorPreferences(AddonPreferences):
    bl_idname = __name__
    
    icons_preview_size: FloatProperty(
        name="Icon Preview Size",
        description="Choose the preview icons dimension",
        default=1.5,
        min=0.5,
        max=3.0
    )
    
    icons_popup_size: FloatProperty(
        name="Icon Popup Size", 
        description="Choose the popup icons dimension",
        default=1.5,
        min=0.5,
        max=3.0
    )
    
    show_labels: BoolProperty(
        name="Show Labels",
        description="Show enum label in preview buttons",
        default=True
    )

def get_hdri_preview_items(self, context):
    """HDRI Preview Callback - Blender 4.2 compatible version"""
    items = []
    
    if context is None:
        return items
    
    try:
        # Find all HDRI images in bpy.data.images
        for idx, img in enumerate(bpy.data.images):
            if img and img.type == 'IMAGE' and img.source in {'FILE', 'SEQUENCE'}:
                # Skip Blender internal images
                if img.name.startswith('Render Result') or img.name.startswith('Viewer Node'):
                    continue
                
                display_name = img.name.replace('.hdr', '').replace('.exr', '').replace('.jpg', '').title()
                
                # Use image preview - this should work in Blender 4.2
                icon_id = 0
                try:
                    if hasattr(img, 'preview'):
                        img.preview_ensure()
                        if img.preview and hasattr(img.preview, 'icon_id'):
                            icon_id = img.preview.icon_id
                except:
                    pass
                
                # Fallback icon
                if icon_id == 0:
                    icon_id = 'FILE_IMAGE'
                
                # Get size info
                try:
                    if img.size[0] > 0:
                        description = f"Size: {img.size[0]}x{img.size[1]}"
                    else:
                        description = "HDRI Image"
                except:
                    description = "HDRI Image"
                
                items.append((img.name, display_name, description, icon_id, idx))
        
    except Exception as e:
        print(f"Error in get_hdri_preview_items: {e}")
        return [("ERROR", "Error Loading Images", str(e), 'ERROR', 0)]
    
    if not items:
        items.append(("NONE", "No HDRI Loaded", "Load an HDR image first", 'FILE_IMAGE', 0))
    
    return items

class HDRI_Properties(PropertyGroup):
    hdri_preview_enum: EnumProperty(
        name="HDRI Previews",
        description="Select HDRI for display",
        items=get_hdri_preview_items
    )

class HDRI_OT_load(Operator, ImportHelper):
    bl_idname = "hdri.load"
    bl_label = "Load HDRI"
    filter_glob: StringProperty(default="*.hdr;*.exr", options={"HIDDEN"})
    def execute(self, context):
        try:
            img = bpy.data.images.load(self.filepath)
            img.pack()
            context.scene.hdri_image = img
            
            # Force preview generation for high-quality display
            try:
                if hasattr(img, 'preview'):
                    img.preview_ensure()
            except Exception as e:
                print(f"Preview generation error: {e}")
            
            # Set the enum to this image
            if hasattr(context.window_manager, 'hdri_properties'):
                context.window_manager.hdri_properties.hdri_preview_enum = img.name
            
            # Force UI refresh - safely handle context
            try:
                if context.screen and hasattr(context.screen, 'areas'):
                    for area in context.screen.areas:
                        if area:
                            area.tag_redraw()
            except:
                pass  # Ignore redraw errors
            
            self.report({"INFO"}, f"Loaded HDRI: {img.name}")
            return {"FINISHED"}
        except Exception as e:
            self.report({"ERROR"}, f"Failed to load HDRI: {str(e)}")
            return {"CANCELLED"}

class HDRI_OT_prev_image(Operator):
    bl_idname = "hdri.prev_image"
    bl_label = "Previous Image"

    def execute(self, context):
        props = context.window_manager.hdri_properties
        items = get_hdri_preview_items(props, context)
        
        if len(items) <= 1:
            return {"CANCELLED"}
        
        current = props.hdri_preview_enum
        current_idx = next((i for i, item in enumerate(items) if item[0] == current), 0)
        new_idx = (current_idx - 1) % len(items)
        props.hdri_preview_enum = items[new_idx][0]
        
        return {"FINISHED"}

class HDRI_OT_next_image(Operator):
    bl_idname = "hdri.next_image"
    bl_label = "Next Image"

    def execute(self, context):
        props = context.window_manager.hdri_properties
        items = get_hdri_preview_items(props, context)
        
        if len(items) <= 1:
            return {"CANCELLED"}
        
        current = props.hdri_preview_enum
        current_idx = next((i for i, item in enumerate(items) if item[0] == current), 0)
        new_idx = (current_idx + 1) % len(items)
        props.hdri_preview_enum = items[new_idx][0]
        
        return {"FINISHED"}

class HDRI_PT_panel(Panel):
    bl_label = "HDRI Editor"
    bl_idname = "HDRI_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "HDRI Editor"
    
    def draw(self, context):
        layout = self.layout
        
        layout.operator("hdri.load", text="Load HDRI", icon="FILE_IMAGE")
        
        if hasattr(context.scene, "hdri_image") and context.scene.hdri_image:
            img = context.scene.hdri_image
            
            box = layout.box()
            box.label(text=f"File: {img.name}", icon="IMAGE_DATA")
            if img.size[0] > 0:
                box.label(text=f"Size: {img.size[0]} x {img.size[1]}")
            
            if img.has_data:
                preview_box = layout.box()
                preview_box.label(text="HDR Image Display:", icon="IMAGE_DATA")
                
                # Get addon preferences - same as sample addon
                addon_prefs = context.preferences.addons[__name__].preferences
                hdri_props = context.window_manager.hdri_properties
                
                # Create navigation layout exactly like sample addon
                col = preview_box.column(align=True)
                row = col.row(align=True)
                
                # Left arrow with sample addon scaling
                left_row = row.row(align=True)
                left_row.scale_y = addon_prefs.icons_preview_size * 6
                left_row.operator("hdri.prev_image", text="", icon='TRIA_LEFT_BAR')
                
                # Preview row with sample addon scaling 
                preview_row = row.row(align=True)
                preview_row.scale_y = addon_prefs.icons_preview_size
                
                # Set popup size based on space type (like sample addon)
                if self.bl_space_type == 'VIEW_3D':
                    popup_size = addon_prefs.icons_popup_size * 5
                else:
                    popup_size = 3
                
                preview_row.template_icon_view(
                    context.window_manager.hdri_properties, "hdri_preview_enum",
                    show_labels=addon_prefs.show_labels,
                    scale_popup=popup_size
                )
                
                # Right arrow with sample addon scaling
                right_row = row.row(align=True)
                right_row.scale_y = addon_prefs.icons_preview_size * 6
                right_row.operator("hdri.next_image", text="", icon='TRIA_RIGHT_BAR')

def register():
    bpy.utils.register_class(HDRI_EditorPreferences)
    bpy.utils.register_class(HDRI_Properties)
    bpy.utils.register_class(HDRI_OT_load)
    bpy.utils.register_class(HDRI_OT_prev_image)
    bpy.utils.register_class(HDRI_OT_next_image)
    bpy.utils.register_class(HDRI_PT_panel)
    
    bpy.types.Scene.hdri_image = bpy.props.PointerProperty(type=bpy.types.Image)
    bpy.types.WindowManager.hdri_properties = bpy.props.PointerProperty(type=HDRI_Properties)

def unregister():
    del bpy.types.WindowManager.hdri_properties
    del bpy.types.Scene.hdri_image
    
    bpy.utils.unregister_class(HDRI_PT_panel)
    bpy.utils.unregister_class(HDRI_OT_next_image)
    bpy.utils.unregister_class(HDRI_OT_prev_image)
    bpy.utils.unregister_class(HDRI_OT_load)
    bpy.utils.unregister_class(HDRI_Properties)
    bpy.utils.unregister_class(HDRI_EditorPreferences)
